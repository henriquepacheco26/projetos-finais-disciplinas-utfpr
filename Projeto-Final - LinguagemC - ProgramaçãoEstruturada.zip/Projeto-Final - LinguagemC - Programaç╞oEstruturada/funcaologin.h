#ifndef FUNCAOLOGIN_H_INCLUDED
#define FUNCAOLOGIN_H_INCLUDED

int loginusuario();

#endif // FUNCAOLOGIN_H_INCLUDED
