#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "funcaomenuinicio.h"

//funcao menu inicio
int menuinicio(){

    //declaracao das variaveis
    int num;

    //menu inicial do mercado
    printf("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
    printf("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
    printf("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
    printf("--------------------------------------------------------------------------------------------- BEM VINDOS AO SISTEMA PACHANO! ------------------------------------------------------------------------------------------------");
    printf("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
    printf("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
    printf("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
    printf("\n\n\n");

    printf("                                                                                         ---------------------------------------                                                                                     ");
    printf("                                                                                       |  DEPARTAMENTO 0: LIMPEZA.           |                                                                                       ");
    printf("                                                                                     |  DEPARTAMENTO 1: ALIMENTOS BASICOS. |                                                                                       ");
    printf("                                                                                     |  DEPARTAMENTO 2: FRUTAS/FEIRA.      |                                                                                       ");
    printf("                                                                                     |  DEPARTAMENTO 3: ACOUGUE.           |                                                                                       ");
    printf("                                                                                     |  DEPARTAMENTO 4: BEBIDAS.           |                                                                                       ");
    printf("                                                                                     |  DEPARTAMENTO 5: HIGIENE.           |                                                                                       ");
    printf("                                                                                     ---------------------------------------                                                                                        ");
    printf("\n\n\n");

    printf("\n   DIGITE O DEPARTAMENTO DESEJADO: ");
    scanf("%d", &num);
    sleep(1);

    //verificando se num esta entre 0 e 5, caso nao, fica repetindo pro usuario ate um num valido ser digitado
    while(num < 0 || num > 5){
            printf("\n ID INVALIDO, DIGITE NOVAMENTE: ");
            scanf("%d", &num);
        }

    //chamando as funcoes para cada departamento escolhido, com seus respectivos parametros
    switch(num){
        case 0:
            system("cls");
            menudep("LIMPEZA");
            arquivo("precosprodutosdep1.txt", "produtosdep1.txt");
            departamentos();
            break;

        case 1:
            system("cls");
            menudep("ALIMENTOS BASICOS");
            arquivo("precosprodutosdep2.txt", "produtosdep2.txt");
            departamentos();
            break;

        case 2:
            system("cls");
            menudep("FRUTAS/FEIRA");
            arquivo("precosprodutosdep3.txt", "produtosdep3.txt");
            departamentos();
            break;

        case 3:
            system("cls");
            menudep("ACOUGUE");
            arquivo("precosprodutosdep4.txt", "produtosdep4.txt");
            departamentos();
            break;

        case 4:
            system("cls");
            menudep("BEBIDAS");
            arquivo("precosprodutosdep5.txt", "produtosdep5.txt");
            departamentos();
            break;

        case 5:
            system("cls");
            menudep("HIGIENE");
            arquivo("precosprodutosdep6.txt", "produtosdep6.txt");
            departamentos();
            break;
        }
}
