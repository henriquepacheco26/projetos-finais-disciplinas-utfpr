#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "funcaodepartamentos.h"

float *vetprecos;//ponteiro usado na funcao departamento e na funcao arquivo
                 //o mesmo pega o preco do produto digitado pelo usuario

int quant, troco;//variaveis usadas na nota fiscal da compra, com seus respectivos valores
int valipag, pagamento;//variaveis usadas no processo e validacao de pagamento
int prod;

//funcao criada para o menu do departamento
int menudep(char *titulo){

    printf("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
    printf("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
    printf("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
    printf("----------------------------------------------------------------------------------------------------- %s ------------------------------------------------------------------------------------------------", titulo);
    printf("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
    printf("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
    printf("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
    printf("\n\n\n");

    return(menudep);
}

int arquivo(char *precosprods, char *prods){

    int id_produto, id_preco, tam=30, quant, i;
    char produto[tam];

    printf("               PRODUTOS\n ");

    //leitura do arquivo txt
    FILE* produtos = fopen(prods, "r");

    //verificando se e diferente de null
    if(produtos != NULL){
        printf("----------------------------------------");

        while(fscanf(produtos, "%d %[^\n]s", &id_produto, produto) != EOF){//end of file, l� todas as linhas do arquivo
            printf(" \n");
            printf("  %d - %s", id_produto, produto);
        }
        printf("\n ----------------------------------------");
        printf("\n\n\n");
    }
        fclose(produtos);//fechando o arquivo

    printf("               PRECOS\n ");

    FILE* precosproduto = fopen(precosprods, "r");

    //verificando se e diferente de null
    if(precosproduto != NULL){
        fscanf(precosproduto, "%d", &quant);

        vetprecos = (float*) malloc(quant * sizeof(float));//aloca��o de memoria feita para o ponteiro vetprecos

            if(vetprecos == NULL){
                printf("\n ERRO AO ALOCAR MEMORIA.\n");
                exit(1);
            }
                i=0;

        printf("----------------------------------------\n");
        while(fscanf(precosproduto, "%d %f", &id_preco, &vetprecos[i]) != EOF){//ponteiro de vetprecos pega o conteudo de acordo com o produto digitado, caso produto 1, pega o pre�o do produto 1
            printf(" %d - %.2f\n", id_preco, vetprecos[i]);
            i++;
        }

        printf(" ----------------------------------------");
        printf("\n\n\n");
    }
        fclose(precosproduto);

    return(arquivo);
}

//funcao departamentos
int departamentos(){

    //declaracao das variaveis
    int i;
    char senha[6];

    //menu escolha dos produtos
    printf("\n DIGITE O PRODUTO DESEJADO (PELO ID): ");
    scanf("%d", &prod);
    sleep(1);

    //verificacao de digito invalido, caso nao esteja dentro da condicao fica se repetindo ate ser digitado um digito valido
    while(prod < 0 || prod > 9){
        printf("\n ID INVALIDO, DIGITE NOVAMENTE: ");
        scanf("%d", &prod);
    }

    //pedindo a quantidade desejada pelo cliente pro produto escolhido
    printf("\n DIGITE A QUANTIDADE DESEJADA: ");
    scanf("%d", &quant);
    sleep(1);


    printf("\n FORMAS DE PAGAMENTO: ");
    printf("\n 1 - DINHEIRO.");
    printf("\n 2 - CARTAO DE CREDITO/DEBITO.\n");
    printf("\n QUAL A DESEJADA: ");
    scanf("%d", &pagamento);

    sleep(1);

        //verificacao de digito invalido, caso nao esteja dentro da condicao fica se repetindo ate ser digitado um digito valido
        while(pagamento != 1 && pagamento != 2){
            printf("\n ID INVALIDO, DIGITE NOVAMENTE: ");
            scanf("%d", &pagamento);
        }

            if(pagamento == 1){
                printf("\n PRECISA DE TROCO? 1 PARA SIM, 2 PARA NAO: ");
                scanf("%d", &valipag);
                sleep(1);

                //verificacao de digito invalido, caso nao esteja dentro da condicao fica se repetindo ate ser digitado um digito valido
                while(valipag != 1 && valipag != 2){
                    printf("\n ID INVALIDO, DIGITE NOVAMENTE: ");
                    scanf("%d", &valipag);
                }

                    if(valipag == 1){
                        printf("\n DIGITE O VALOR DO TROCO: ");
                        scanf("%d", &troco);

                        while(troco < (vetprecos[prod] * quant)){
                            sleep(1);
                            printf("\n VALOR DIGITADO INSUFICIENTE PARA O PRODUTO, DIGITE NOVAMENTE: ");
                            scanf("%d", &troco);
                        }

                        notafiscal();

                    }else{
                        notafiscal();
                    }

            }else if(pagamento == 2){
                printf("\n DIGITE A SENHA (ATE 6 DIGITOS): ");

                //for criado para substituir os caracteres digitados por '*' e esconder a senha do usuario.
                for(i=0; i<6; i++){
                    senha[i] = getch();
                    putchar('*');
                }

                scanf("%c", &senha);
                sleep(1);
                notafiscal();
            }

    return(departamentos);
}

//funcao criada para apresentar a nota fiscal ao cliente, com seu numero, produtos comprados e o valor total da compra
int notafiscal(){

    int i;

    printf("\n NUMERO DA NOTA FISCAL: ");

    for (i=0; i <10; i++){
        printf("%d", rand() % 100);//gerando valores aleatorios entre 0 e 100
    }
        printf("\n\n");
        system("pause");
        getch();

        if(valipag == 1){
            printf("\n VALOR DA COMPRA: R$ %.2f.\n", vetprecos[prod] * quant);//preco do produto(apontando pelo ponteiro) * a quantidade digitada
            sleep(1);
            printf("\n TROCO DO CLIENTE: R$ %.2f.\n", troco - (vetprecos[prod] * quant));// troco digitado - preco do produto(apontando pelo ponteiro) * a quantidade digitada
            sleep(1);
            printf("\n COMPRA REALIZADA COM SUCESSO, OBRIGADO. \n");
            sleep(1);
        }else{
        }

            if(valipag == 2){
                printf("\n VALOR DA COMPRA: R$ %.2f.\n", vetprecos[prod] * quant);//preco do produto(apontando pelo ponteiro) * a quantidade digitada
                sleep(1);
                printf("\n COMPRA REALIZADA COM SUCESSO, OBRIGADO. \n");
                sleep(1);
            }else{
            }

                if(pagamento == 2){
                    printf("\n VALOR DA COMPRA: R$ %.2f.\n", vetprecos[prod] * quant);//preco do produto(apontando pelo ponteiro) * a quantidade digitada
                    sleep(1);
                    printf("\n COMPRA REALIZADA COM SUCESSO, OBRIGADO.");
                    sleep(1);
                }else{
                }

                    printf("\n");

                    voltasis();

        return 0;
}

//funcao criada para voltar ao sistema no fim da compra caso desejado
int voltasis(){


    int voltasis;

    printf("\n DIGITE 1 PARA VOLTAR AO SISTEMA, 2 PARA FECHA-LO: ");
    scanf("%d", &voltasis);

    //verificacao de digito invalido, caso nao esteja dentro da condicao fica se repetindo ate ser digitado um digito valido
    while(voltasis != 1 && voltasis != 2){
        printf("\n ID INVALIDO, DIGITE NOVAMENTE: ");
        scanf("%d", &voltasis);
    }
        if(voltasis == 1){
            system("cls");
            menuinicio();//volta pro menuinicio

        }else if(voltasis == 2){
            exit(departamentos);//encerra o programa
        }

        return(voltasis);
}
