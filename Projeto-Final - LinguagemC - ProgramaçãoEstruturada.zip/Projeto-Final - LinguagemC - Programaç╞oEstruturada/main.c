#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "funcaologin.h"
#include "funcaomenuinicio.h"
#include "funcaodepartamentos.h"

int main()
{
    system("color 30");//alterar a cor de fundo do prompt

    loginusuario();
    sleep(1);
    system("cls");
    printf("\n LOGIN EFETUADO.");
    printf("\n BOAS COMPRAS.\n");

    menuinicio();

    return 0;
}
