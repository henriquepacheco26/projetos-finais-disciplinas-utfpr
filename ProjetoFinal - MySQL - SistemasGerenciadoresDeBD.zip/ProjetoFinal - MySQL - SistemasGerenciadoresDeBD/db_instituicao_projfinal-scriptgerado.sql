-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- SET SQL_SAFE_UPDATES = 0;
-- -----------------------------------------------------
-- Schema db_instituicao_projfinal
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `db_instituicao_projfinal` DEFAULT CHARACTER SET utf8 ;
USE `db_instituicao_projfinal` ;

-- -----------------------------------------------------
-- Table `db_instituicao_projfinal`.`tb_sexo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_instituicao_projfinal`.`tb_sexo` (
  `sex_id` INT NOT NULL AUTO_INCREMENT,
  `sex_descricao` VARCHAR(9) NOT NULL,
  PRIMARY KEY (`sex_id`))
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `db_instituicao_projfinal`.`tb_bairro`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_instituicao_projfinal`.`tb_bairro` (
  `bai_id` INT NOT NULL AUTO_INCREMENT,
  `bai_descricao` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`bai_id`))
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `db_instituicao_projfinal`.`tb_logradouro`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_instituicao_projfinal`.`tb_logradouro` (
  `log_id` INT NOT NULL AUTO_INCREMENT,
  `log_descricao` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`log_id`))
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `db_instituicao_projfinal`.`tb_endPostal`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_instituicao_projfinal`.`tb_endPostal` (
  `endP_id` INT NOT NULL AUTO_INCREMENT,
  `endP_bai_id` INT NOT NULL,
  `endP_log_id` INT NOT NULL,
  `endP_nomeRua` VARCHAR(45) NOT NULL,
  `endP_cep` VARCHAR(9) NOT NULL,
  PRIMARY KEY (`endP_id`),
  INDEX `fk_tb_endPostal_tb_bairro1_idx` (`endP_bai_id` ASC) VISIBLE,
  INDEX `fk_tb_endPostal_tb_logradouro1_idx` (`endP_log_id` ASC) VISIBLE,
  CONSTRAINT `fk_tb_endPostal_tb_bairro1`
    FOREIGN KEY (`endP_bai_id`)
    REFERENCES `db_instituicao_projfinal`.`tb_bairro` (`bai_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tb_endPostal_tb_logradouro1`
    FOREIGN KEY (`endP_log_id`)
    REFERENCES `db_instituicao_projfinal`.`tb_logradouro` (`log_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `db_instituicao_projfinal`.`tb_endereco`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_instituicao_projfinal`.`tb_endereco` (
  `end_id` INT NOT NULL AUTO_INCREMENT,
  `end_endP_id` INT NOT NULL,
  `end_numero` VARCHAR(15) NOT NULL,
  `end_complemento` VARCHAR(45) NULL,
  PRIMARY KEY (`end_id`),
  INDEX `fk_tb_endereco_tb_endPostal1_idx` (`end_endP_id` ASC) VISIBLE,
  CONSTRAINT `fk_tb_endereco_tb_endPostal1`
    FOREIGN KEY (`end_endP_id`)
    REFERENCES `db_instituicao_projfinal`.`tb_endPostal` (`endP_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `db_instituicao_projfinal`.`tb_pessoa`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_instituicao_projfinal`.`tb_pessoa` (
  `pes_cpf` VARCHAR(14) NOT NULL,
  `pes_sexo_id` INT NOT NULL,
  `pes_end_id` INT NOT NULL,
  `pes_nome` VARCHAR(100) NOT NULL,
  `pes_dt_nasc` DATE NOT NULL,
  `pes_telefone` VARCHAR(14) NULL,
  `pes_email` VARCHAR(45) NULL,
  PRIMARY KEY (`pes_cpf`),
  INDEX `fk_tb_pessoa_tb_sexo1_idx` (`pes_sexo_id` ASC) VISIBLE,
  INDEX `fk_tb_pessoa_tb_endereco1_idx` (`pes_end_id` ASC) VISIBLE,
  CONSTRAINT `fk_tb_pessoa_tb_sexo1`
    FOREIGN KEY (`pes_sexo_id`)
    REFERENCES `db_instituicao_projfinal`.`tb_sexo` (`sex_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tb_pessoa_tb_endereco1`
    FOREIGN KEY (`pes_end_id`)
    REFERENCES `db_instituicao_projfinal`.`tb_endereco` (`end_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `db_instituicao_projfinal`.`tb_professor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_instituicao_projfinal`.`tb_professor` (
  `prof_ra` VARCHAR(8) NOT NULL,
  `prof_pes_cpf` VARCHAR(14) NOT NULL,
  INDEX `fk_tb_professor_tb_pessoa_idx` (`prof_pes_cpf` ASC) VISIBLE,
  UNIQUE INDEX `prof_ra_UNIQUE` (`prof_ra` ASC) VISIBLE,
  PRIMARY KEY (`prof_ra`),
  CONSTRAINT `fk_tb_professor_tb_pessoa`
    FOREIGN KEY (`prof_pes_cpf`)
    REFERENCES `db_instituicao_projfinal`.`tb_pessoa` (`pes_cpf`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `db_instituicao_projfinal`.`tb_periodo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_instituicao_projfinal`.`tb_periodo` (
  `per_id` INT NOT NULL AUTO_INCREMENT,
  `per_descricao` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`per_id`))
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `db_instituicao_projfinal`.`tb_semestre`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_instituicao_projfinal`.`tb_semestre` (
  `sem_id` INT NOT NULL AUTO_INCREMENT,
  `sem_duracao` INT NOT NULL,
  PRIMARY KEY (`sem_id`))
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `db_instituicao_projfinal`.`tb_curso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_instituicao_projfinal`.`tb_curso` (
  `cur_id` INT NOT NULL AUTO_INCREMENT,
  `cur_nome` VARCHAR(45) NOT NULL,
  `cur_sigla` VARCHAR(10) NOT NULL,
  `cur_dataInicio` DATE NULL,
  `cur_per_id` INT NOT NULL,
  `cur_sem_id` INT NOT NULL,
  PRIMARY KEY (`cur_id`),
  INDEX `fk_tb_curso_tb_periodo1_idx` (`cur_per_id` ASC) VISIBLE,
  INDEX `fk_tb_curso_tb_semestre1_idx` (`cur_sem_id` ASC) VISIBLE,
  CONSTRAINT `fk_tb_curso_tb_periodo1`
    FOREIGN KEY (`cur_per_id`)
    REFERENCES `db_instituicao_projfinal`.`tb_periodo` (`per_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tb_curso_tb_semestre1`
    FOREIGN KEY (`cur_sem_id`)
    REFERENCES `db_instituicao_projfinal`.`tb_semestre` (`sem_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `db_instituicao_projfinal`.`tb_disciplina`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_instituicao_projfinal`.`tb_disciplina` (
  `disc_id` INT NOT NULL AUTO_INCREMENT,
  `disc_cur_id` INT NOT NULL,
  `disc_nome` VARCHAR(45) NOT NULL,
  `disc_sigla` VARCHAR(10) NOT NULL,
  `disc_semestre` INT NOT NULL,
  `disc_aulasSemana` INT NOT NULL,
  `disc_cargaHRTotal` INT NOT NULL,
  PRIMARY KEY (`disc_id`),
  INDEX `fk_tb_disciplina_tb_curso1_idx` (`disc_cur_id` ASC) VISIBLE,
  CONSTRAINT `fk_tb_disciplina_tb_curso1`
    FOREIGN KEY (`disc_cur_id`)
    REFERENCES `db_instituicao_projfinal`.`tb_curso` (`cur_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `db_instituicao_projfinal`.`tb_aluno`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_instituicao_projfinal`.`tb_aluno` (
  `aluno_ra` VARCHAR(8) NOT NULL,
  `alu_pes_cpf` VARCHAR(14) NOT NULL,
  UNIQUE INDEX `aluno_ra_UNIQUE` (`aluno_ra` ASC) VISIBLE,
  INDEX `fk_tb_aluno_tb_pessoa1_idx` (`alu_pes_cpf` ASC) VISIBLE,
  PRIMARY KEY (`aluno_ra`),
  CONSTRAINT `fk_tb_aluno_tb_pessoa1`
    FOREIGN KEY (`alu_pes_cpf`)
    REFERENCES `db_instituicao_projfinal`.`tb_pessoa` (`pes_cpf`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `db_instituicao_projfinal`.`tb_matriculaAlunoCurso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_instituicao_projfinal`.`tb_matriculaAlunoCurso` (
  `mat_alcu_aluno_ra` VARCHAR(8) NOT NULL,
  `mat_alcu_cur_id` INT NOT NULL,
  `mat_alcu_situacao` VARCHAR(45) NOT NULL,
  `mat_alcu_data` DATE NOT NULL,
  PRIMARY KEY (`mat_alcu_aluno_ra`, `mat_alcu_cur_id`),
  INDEX `fk_tb_aluno_has_tb_curso_tb_curso1_idx` (`mat_alcu_cur_id` ASC) VISIBLE,
  INDEX `fk_tb_matriculaAlunoCurso_tb_aluno1_idx` (`mat_alcu_aluno_ra` ASC) VISIBLE,
  CONSTRAINT `fk_tb_aluno_has_tb_curso_tb_curso1`
    FOREIGN KEY (`mat_alcu_cur_id`)
    REFERENCES `db_instituicao_projfinal`.`tb_curso` (`cur_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tb_matriculaAlunoCurso_tb_aluno1`
    FOREIGN KEY (`mat_alcu_aluno_ra`)
    REFERENCES `db_instituicao_projfinal`.`tb_aluno` (`aluno_ra`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `db_instituicao_projfinal`.`tb_turma`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_instituicao_projfinal`.`tb_turma` (
  `tur_id` INT NOT NULL AUTO_INCREMENT,
  `tur_disc_id` INT NOT NULL,
  `tur_sigla` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`tur_id`),
  INDEX `fk_tb_turma_tb_disciplina1_idx` (`tur_disc_id` ASC) VISIBLE,
  CONSTRAINT `fk_tb_turma_tb_disciplina1`
    FOREIGN KEY (`tur_disc_id`)
    REFERENCES `db_instituicao_projfinal`.`tb_disciplina` (`disc_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `db_instituicao_projfinal`.`tb_matriculaAlunoTur`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_instituicao_projfinal`.`tb_matriculaAlunoTur` (
  `mat_altur_tur_id` INT NOT NULL,
  `mat_altur_alcur_cur_id` INT NOT NULL,
  PRIMARY KEY (`mat_altur_tur_id`),
  INDEX `fk_tb_aluno_has_tb_turma_tb_turma1_idx` (`mat_altur_tur_id` ASC) VISIBLE,
  INDEX `fk_tb_matriculaAlunoTur_tb_matriculaAlunoCurso1_idx` (`mat_altur_alcur_cur_id` ASC) VISIBLE,
  CONSTRAINT `fk_tb_aluno_has_tb_turma_tb_turma1`
    FOREIGN KEY (`mat_altur_tur_id`)
    REFERENCES `db_instituicao_projfinal`.`tb_turma` (`tur_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tb_matriculaAlunoTur_tb_matriculaAlunoCurso1`
    FOREIGN KEY (`mat_altur_alcur_cur_id`)
    REFERENCES `db_instituicao_projfinal`.`tb_matriculaAlunoCurso` (`mat_alcu_cur_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `db_instituicao_projfinal`.`tb_professorTurma`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_instituicao_projfinal`.`tb_professorTurma` (
  `profTur_prof_ra` VARCHAR(8) NOT NULL,
  `profTur_tur_id` INT NOT NULL,
  INDEX `fk_tb_professor_has_tb_turma_tb_turma1_idx` (`profTur_tur_id` ASC) VISIBLE,
  INDEX `fk_tb_professorTurma_tb_professor1_idx` (`profTur_prof_ra` ASC) VISIBLE,
  PRIMARY KEY (`profTur_prof_ra`, `profTur_tur_id`),
  CONSTRAINT `fk_tb_professor_has_tb_turma_tb_turma1`
    FOREIGN KEY (`profTur_tur_id`)
    REFERENCES `db_instituicao_projfinal`.`tb_turma` (`tur_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tb_professorTurma_tb_professor1`
    FOREIGN KEY (`profTur_prof_ra`)
    REFERENCES `db_instituicao_projfinal`.`tb_professor` (`prof_ra`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;




-- -----------------------------------------------------
-- SELECTS
-- -----------------------------------------------------
select * from tb_aluno;
select * from tb_bairro;
select * from tb_curso;
select * from tb_disciplina;
select * from tb_endereco;
select * from tb_endpostal;
select * from tb_logradouro;
select * from tb_matriculaalunocurso;
select * from tb_matriculaalunotur;
select * from tb_periodo;
select * from tb_pessoa;
select * from tb_professor;
select * from tb_professorturma;
select * from tb_semestre;
select * from tb_sexo;
select * from tb_turma;




-- -----------------------------------------------------
-- INSERTS
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Table tb_aluno
-- -----------------------------------------------------
INSERT INTO tb_aluno
	 VALUES ('4158963', '44284971050'), ('3258996', '47797849056'), ('2541778', '64011100072'), 
			('3698552', '59761325024'), ('9654885', '55247851423'), ('9963225', '21610014006');

-- -----------------------------------------------------
-- Table tb_bairro
-- -----------------------------------------------------
INSERT INTO tb_bairro
	 VALUES 
		(NULL, 'Cidade Alta'), (NULL, 'São Luís'), (NULL, 'Baixada Amarela'), (NULL, 'Centro'), (NULL, 'Navegantes'), (NULL, 'Cidade Nova'), (NULL, 'Parque Industrial'), 
        (NULL, 'Parque Verde'), (NULL, 'Porto'), (NULL, 'São Roque');

-- -----------------------------------------------------
-- Table tb_curso
-- -----------------------------------------------------
INSERT INTO tb_curso
	 VALUES 
		(NULL, 'Ciencia da Computação', 'CC', '2015-01-15', 8, 2), (NULL, 'Analise e Desenvolvimento de Sistemas', 'ADS', '2020-07-05', 6, 1),
        (NULL, 'Ciencias Biologicas', 'BIO', '2016-07-01', 8, 2), (NULL, 'Medicina', 'MED', '2019-06-07', 10, 3),
        (NULL, 'Agronomia', 'AGRO', '2014-02-10', 10, 3), (NULL, 'Administração', 'ADM', '2018-06-08', 10, 3);
        
-- -----------------------------------------------------
-- Table tb_disciplina
-- -----------------------------------------------------
INSERT INTO tb_disciplina
	 VALUES 
		(NULL, 1, 'Sistemas Gerenciados de Bancos de Dados', 'SGBD', 3, 2, 60), (NULL, 2, 'Biologia do Corpo Humano', 'BCH', 1, 3, 45), 
        (NULL, 3, 'Matemática Aplicada a Agronomia', 'MAA', 2, 4, 60), (NULL, 4, 'Contabilidade', 'CTB', 1, 3, 60), 
        (NULL, 5, 'Lógica de Progamação', 'LPR', 1, 3, 45), (NULL, 6, 'Anatomia', 'ANT', 2, 4, 45);

-- -----------------------------------------------------
-- Table tb_endereco
-- -----------------------------------------------------
INSERT INTO tb_endereco 
	 VALUES (NULL, 21, 146, 'Casa'),	(NULL, 22, 445, 'Apartamento'), (NULL, 23, 33, 'Casa'), (NULL, 24, 334, 'Casa'), (NULL, 25, 77, 'Apartamento'),
			(NULL, 26, 678, 'Casa'), (NULL, 27, 143, 'Apartamento'), (NULL, 28, 90, 'Apartamento'), (NULL, 29, 99, 'Apartamento'), (NULL, 30, 106, 'Casa');

-- -----------------------------------------------------
-- Table tb_endpostal
-- -----------------------------------------------------
INSERT INTO tb_endPostal
	  VALUES (NULL, 1, 1, 'Passáro', '83209659'),
			 (NULL, 2, 2, 'Olavo Filho', '29024553'),
             (NULL, 3, 3, 'Augusto Moreira', '76822020'),
             (NULL, 4, 4, 'Tiradentes',	'69304335'),
             (NULL, 5, 5, 'Arinos', '68701010'),
             (NULL, 6, 6, 'Bahia', '68905511'),
             (NULL, 7, 7, 'Benjamim', '38408660'),
             (NULL, 8, 8, 'Brasilia', '29709363'),
             (NULL, 9, 9, 'Cipestre', '27966622'),
             (NULL, 10, 10, 'Colono', '78730600');

-- -----------------------------------------------------
-- Table tb_logradouro
-- -----------------------------------------------------
INSERT INTO tb_logradouro
  VALUES 
	(NULL, '15 de Novembro'), (NULL, '7 Irmãos'), (NULL, 'Airton Senna'), (NULL, 'Alecrim'), (NULL, 'Alto'), (NULL, 'Angelo Cattani'), (NULL, 'Angico'), 
    (NULL, 'Amazonas'), (NULL, 'Aparonga'), (NULL, 'Argentina');

-- -----------------------------------------------------
-- Table tb_matriculaalunocurso
-- -----------------------------------------------------
INSERT INTO tb_matriculaalunocurso
  VALUES 
	('9963225', 1, 'Regular', '2020-02-10'), ('4158963', 1, 'Irregular', '2016-07-05'), ('3258996', 4, 'Regular', '2021-02-07'), 
    ('9654885', 6, 'Regular', '2018-07-12'), ('3698552', 3, 'Irregular', '2019-02-05'), ('2541778', 2, 'Regular', '2022-02-03');
    
-- -----------------------------------------------------
-- Table tb_matriculaalunotur
-- -----------------------------------------------------
INSERT INTO tb_matriculaalunotur
  VALUES 
	(7, 2), (8, 4), (9, 3), (10, 1), (11, 6), (12, 1);
    
-- -----------------------------------------------------
-- Table tb_periodo
-- -----------------------------------------------------
INSERT INTO tb_periodo
  VALUES 
	(NULL, '1º Periodo'), (NULL, '2º Periodo'), (NULL, '3º Periodo'), (NULL, '4º Periodo'), (NULL, '5º Periodo'), 
    (NULL, '6º Periodo'), (NULL, '7º Periodo'), (NULL, '8º Periodo'), (NULL, '9º Periodo'), (NULL, '10º Periodo');

-- -----------------------------------------------------
-- Table tb_pessoa
-- -----------------------------------------------------
INSERT INTO tb_pessoa
	 VALUES ('55247851423', 1, 51, 'Fernando Aparecido', '1998-05-12','12582358', 'fer_apa@gmail.com'),
			('44284971050', 2, 52, 'Julia Freitas', '2002-08-15','36020711', 'ju_frei@gmail.com'),
            ('47797849056', 3, 53, 'Afonso Padilha', '1976-07-25','26553126', 'afon_pad@gmail.com'),
            ('21610014006', 1, 54, 'Thiago Ventura', '1985-11-27','23265406', 'thi_ven@gmail.com'),
            ('64011100072', 2, 55, 'Roberta Miranda', '1997-12-11','23782416', 'rob_mira@gmail.com'),
            ('59761325024', 3, 56, 'Neymar JR', '2008-02-28','33854015', 'neymar@gmail.com'),
            ('10991285018', 1, 57, 'Bolsonaro Souza', '1999-03-13','88670773', 'bolso_sou@gmail.com'),
            ('55150904031', 2, 58, 'Soraya Silva', '1977-10-19','24917477', 'so_sil@gmail.com'),
            ('64411464012', 3, 59, 'Lula Paulo', '1958-02-22','28175745', 'lu_paul@gmail.com'),
            ('26002448080', 1, 60, 'Fernando Alonso', '1966-01-29','25703521', 'fer_alo@gmail.com');

-- -----------------------------------------------------
-- Table tb_professor
-- -----------------------------------------------------
INSERT INTO tb_professor
	 VALUES ('1025888', '26002448080'), ('8569231', '64411464012'), ('9631258', '55150904031'), ('3201747', '10991285018');

-- -----------------------------------------------------
-- Table tb_professorturma
-- -----------------------------------------------------
INSERT INTO tb_professorturma
	 VALUES ('3201747', 7), ('9631258', 8), ('8569231', 9), ('1025888', 10),
			('8569231', 11), ('9631258', 12);
            
            
-- -----------------------------------------------------
-- Table tb_semestre
-- -----------------------------------------------------
INSERT INTO tb_semestre
  VALUES 
	(NULL, 6), (NULL, 8), (NULL, 10);

-- -----------------------------------------------------
-- Table tb_sexo
-- -----------------------------------------------------
INSERT INTO tb_sexo 
  VALUES (NULL, 'Masculino'), (NULL, 'Feminino'), (NULL, 'Outros');

-- -----------------------------------------------------
-- Table tb_turma
-- -----------------------------------------------------
INSERT INTO tb_turma 
  VALUES (NULL, 7, 'CC22B'), (NULL, 8, 'AG23C'), (NULL, 9, 'BB23D'), (NULL, 10, 'DF23E'), (NULL, 11, 'ED117D'), (NULL, 12, 'OP5BG');
  
  
  
  
  
  -- -----------------------------------------------------
-- CONSULTAS
-- -----------------------------------------------------
-- pessoas que são alunos
select pes_nome, aluno_ra from tb_pessoa
inner join tb_aluno on pes_cpf = alu_pes_cpf;

-- pessoas que são professores
select pes_nome, prof_ra from tb_pessoa
inner join tb_professor on pes_cpf = prof_pes_cpf;

-- pessoa que mora no endereco de numero 445
select pes_nome, end_numero, end_complemento from tb_pessoa
inner join tb_endereco on end_id = pes_end_id
where end_numero = 445;

-- pessoas que nasceram antes ou depois do ano 2000
-- só mudar a condicao de < para >
select pes_nome, pes_dt_nasc from tb_pessoa
where pes_dt_nasc > '2000-01-01';

-- dados da pessoa (professor) que mora no endereco = id 58
select pes_nome, pes_cpf, prof_ra, end_numero, end_complemento from tb_pessoa
inner join tb_professor on pes_cpf = prof_pes_cpf
inner join tb_endereco on end_id = pes_end_id
where pes_end_id = 58;

-- funcoes de linha e agregacao
-- colocando o nome das disciplinas em caixa baixa / letra minusculas
select disc_id, lower(disc_nome) from tb_disciplina;

-- colocando o nome das pessoas em caixa alta / letras maisculas
select pes_cpf, upper(pes_nome) from tb_pessoa;

-- operadores de conjunto
-- union de alunos e professores
(select pes_cpf, pes_nome from tb_professor 
	join tb_pessoa on pes_cpf = prof_pes_cpf)
union
(select pes_cpf, pes_nome from tb_aluno 
	join tb_pessoa on pes_cpf = alu_pes_cpf);
    
-- sub consultas
-- cursos que possuem mais de 8 semestre de duracao
select cur_nome, sem_duracao from tb_curso
join tb_semestre on  sem_id = cur_sem_id
	where sem_duracao = (select sem_duracao 
		from tb_semestre 
			where sem_duracao > 8);
            
-- comandos especiais 
select * from bak_tb_turma;

-- create
-- criando a tabela bak_tb_turma para fazer o insert, update e remove
create table bak_tb_turma
	as (select tur_id, tur_sigla from tb_turma
		join tb_disciplina on disc_id = tur_disc_id);

-- insert
-- inserindo as mesmas siglas de turmas com as letras minusculas / caixa baixa
insert into bak_tb_turma
	select tur_id, lower(tur_sigla)
		from tb_turma
			join tb_disciplina on disc_id = tur_disc_id;
            
-- update
-- alterando a siglas para caixa baixa com o valor/dados da tabela tb_turma com sigla de id 7
update bak_tb_turma
	set tur_sigla = 
		(select lower(tur_sigla) from tb_turma
			where tur_id = 7);
                
-- delete
-- excluir siglas das turmas onde siglas de bak forem = siglas de turma original
-- nesse caso excluiu tudo, pq eu só a tinha sigla de id 7, que era igual a da tabela original
delete from bak_tb_turma
	where exists (select * from tb_turma
		where tur_sigla = tur_sigla);

-- visão
-- view que mostra o nome do curso, sua sigla e sua duração
create view view_curso_duracao (nomeCurso, siglaCurso, duracaoSemestreCurso) 
	as select cur_nome, cur_sigla, sem_duracao from tb_curso
		join tb_semestre on sem_id = cur_sem_id;

select * from view_curso_duracao;
select * from view_curso_duracao where duracaoSemestreCurso > 8;
select * from view_curso_duracao where duracaoSemestreCurso = 6;
select nomeCurso from view_curso_duracao where siglaCurso = 'CC';

-- funções
-- funcao que retorna o nome do aluno de acordo com o cpf dele
delimiter // 
	create function nome_aluno_cpf(alu_pes_cpf char(14))
		returns varchar(50) deterministic
	begin
		declare nomeAluno varchar(50);
			select pes_nome into nomeAluno from tb_pessoa
				join tb_aluno on pes_cpf = alu_pes_cpf limit 1;
		return nomeAluno;
end; //

-- show function status;
-- show create function nome_aluno_cpf;
-- select nome_aluno_cpf('21610014006') as nomeAluno;

-- procedimentos
-- procedimento que atualiza a situação de matricula do aluno de acordo com seu ra
delimiter //
	create procedure atualiza_matricula
		(in aluno_ra char(8), in mat_alcu_situacao char(45))
	begin
		update tb_matriculaalunocurso
			set mat_alcu_situacao = mat_alcu_situacao
				where aluno_ra = mat_alcu_aluno_ra;
end; //

-- show procedure status;
-- show create procedure atualiza_matricula;
-- call atualiza_matricula('9963225', 'Irregular');

-- triggers
-- update
-- trigger que proibe o usuario de atualizar a data de nascimento de uma pessoa, caso os valores sejam iguais, gerando msg de erro
delimiter //
	create trigger valida_data_nascimento
    before update on tb_pessoa 
    for each row
    begin
		if(old.pes_dt_nasc) = new.pes_dt_nasc
			then signal sqlstate '45000'
				set message_text = 'Proibido a atualização da data de nascimento desejada, dados iguais, verifique a inserção e tente novamente.';
		end if;
end; //

-- update tb_pessoa
	-- set pes_dt_nasc = '2009-02-28'
-- where pes_nome = 'Neymar JR';

-- show triggers;

-- eventos
-- select @@event_scheduler; -- verifica status do MYSQL EVENT SCHEDULER
-- set global event_scheduler = on; -- coloca o MYSQL SCHEDULER em modo ativo
-- set global event_scheduler = off; -- coloca o MYSQL SCHEDULER em modo inativo
-- show processlist;
-- show events;

-- evento que adiciona um bairro novo, na tabela de bairros, após 30 segundos
delimiter //
	create event novo_bairro on schedule at current_timestamp() + interval 30 second
		do begin
			insert into tb_bairro(bai_descricao)
				values('Morumbi');
		end; //

-- alter event novo_bairro disable/enable;

-- evento que adiciona um logradouro novo, na tabela de logradouro, após 30 segundos
delimiter //
	create event novo_logradouro on schedule at current_timestamp() + interval 30 second
		do begin
			insert into tb_logradouro(log_descricao)
				values('Deputado Arnaldo Busato');
		end; //

-- alter event novo_logradouro disable/enable;

-- controle de acesso a usuarios
-- primeiro usuario henriqueUser - só tem acesso a leitura da tabela de pessoas

-- create user 'henriqueTeste' identified by '12345';
-- rename user 'henriqueTeste' to 'henriqueUser';
-- grant select on db_instituicao_projfinal.tb_pessoa to 'henriqueUser';

-- segundo usuario henriqueUser2 - tem acesso ao banco inteiro
-- create user 'henriqueUser2' identified by '123';
-- grant all on db_instituicao_projfinal to 'henriqueUser2';

-- removendo os acessos do usuario1 - henriqueUser
revoke select 
	on db_instituicao_projfinal.tb_pessoa
from henriqueUser;
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------