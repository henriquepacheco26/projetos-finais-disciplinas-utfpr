package com.mycompany.jogodaforca;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author henri
 */

public class Jogodaforca {
    
    public static void main(String[] args) throws Exception{ 
        
        //contador de linhas do arquivo
        LineNumberReader lerLinhas = new LineNumberReader(new FileReader("listadepalavras.txt"));
        lerLinhas.skip(Long.MAX_VALUE); //pula ate a ultima linha e conta quantas foram
        int quantPalavras = lerLinhas.getLineNumber() + 1; //qntd de palavras
        
        System.out.println("\n\t *** Aviso: Palavras do jogo sem acento e sem hífen, tente letra por letra ***");
        
        System.out.println("\n\t *** Temos " + quantPalavras + " palavras para jogar, teste o seu conhecimento! ***");
        lerLinhas.close();
        
        String [] palavras = new String[quantPalavras];
        
        //le o arquivo txt com as palavras
        BufferedReader lerArquivo = new BufferedReader(new FileReader("listadepalavras.txt"));
        String linhaLida;
        int linha = 0;
        
        //percorre cada linha do meu arquivo txt e qnd for null para o laco
        while((linhaLida = lerArquivo.readLine()) != null){
            palavras[linha] = linhaLida;
            linha++;
        }
        lerArquivo.close();

        Scanner in = new Scanner(System.in); //scanner das palavras

        Random random = new Random(); //sorteador de palavras
        int indiceSorteado = random.nextInt(quantPalavras); //indice sorteado - posicao da palavra
        String sorteada = palavras[indiceSorteado]; //palavra sorteada de acordo com indice(posicao)

        System.out.println(sorteada);
        
        //controla os acertos do usuario - cada letra = um acerto
        char[] acertos = new char[sorteada.length()];
        for(int i=0; i < acertos.length; i++){
            acertos[i] = 0;
        }
        
        String letrasUti = "";
       
        char letra;
        boolean ganhou = false;
        int vidas = sorteada.length(); //vidas = ao numero de letras da palavra
        
        //mostra o tamanho da palavra antes do jogo comecar
        for(int i=0; i < sorteada.length(); i++){
            System.out.print(" _ ");
        }
        System.out.print("\n");
        
       //executa o looping pelo menos uma vez e até acertar a palavra
        do{
            System.out.println(
                    "\n" + "Voce tem " + vidas + " vidas "
                    + "\nLetras utilizadas:" + letrasUti 
                    + "\nQual letra voce deseja tentar? ");
            
            letra = in.next().charAt(0); //in = scanner para ler, charAt em 0 para pegar a primeira letra
            letrasUti += " " + letra;
            
            boolean perdeVida = true;
            for(int i=0; i < sorteada.length(); i++){
                //verifica se a letra digitada e igual a letra da palavra sorteada na posicao i
                if(letra == sorteada.charAt(i)){
                    acertos[i] = 1;
                    perdeVida = false;
                }
            }
            
            //tira uma vida do usuario se digitar uma letra que nao tem na palavra
            if(perdeVida){
                vidas--;
            }
            
            System.out.println("\n");
            
            ganhou = true; //usuario pode ter ganhado
            for(int i=0; i < sorteada.length(); i++){
                //se tiver alguma letra que o usuario ainda nao acertou,
                if(acertos[i] == 0){
                    System.out.print(" _ ");
                    ganhou = false; //usuario nao ganhou
                }else{
                    System.out.print(" " + sorteada.charAt(i) + " ");
                }
           }
            
            System.out.println("\n");
            
        }while(!ganhou && vidas>0); //! = nao
        
        //se chegou ate aqui com vidas = ganhou,
        //se nao, perdeu o jogo = forca
        if(vidas != 0){
            System.out.println("\n\t *** Parabens voce adivinhou a palavra. ***");
        }else{
            System.out.println("\n\t *** Voce errou a palavra, FORCA. ***");
            System.out.println("\n\t *** A palavra era: " + sorteada + " ***");
        }
    }
}
